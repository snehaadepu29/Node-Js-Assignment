import React, { Component } from 'react';
import { Route, withRouter } from 'react-router-dom';
import Login from './components/Login';
import Userlist from './components/Userlist';
import Profile from './components/Profile';

import './App.css';

class App extends Component {
  render() {
    return (
      <div className="container">
        <Route exact path="/" component={Login} />
        <Route exact path="/userlist" component={Userlist} />
        <Route exact path="/profile" component={Profile} />
      </div>
    );
  }
}

export default withRouter(App);
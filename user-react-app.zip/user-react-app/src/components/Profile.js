import React, { Fragment, Component } from "react";
import { withRouter } from "react-router-dom";
import axios from "axios";
import { getUser, removeUserSession } from './Common';

class Profile extends Component {
  constructor(props) {
    super(props);
const user = getUser();
if(user){
    this.state = {
      details: null,
      userid : user[0].id
    };
} else {
  this.state = {
      details: null
    };
}

    axios
      .post('http://localhost:3000/api/userdetails/',{id : this.state.userid})
      .then((res) => this.setState({ details: res.data }));

  }


     handleLogout = () => {
      removeUserSession();
      this.props.history.push('/');
    }


  render() {
    console.log(this.props);
    return (
      <Fragment>
        {this.state.details ? (

          <div className="heading1">
            <h3>Profile</h3>
  
{this.state.details.map((res) => {
                return (
                <ul> 
                    <li>Name : {res.name}</li>
                    <li>Email: {res.email}</li>
                    <li>Role: {res.role}</li>
                  </ul>
                );
              })}
  
<input type="button" onClick={this.handleLogout} value="Logout" />
          </div>

        ) : null}
        
      </Fragment>
    );
  }
}

export default withRouter(Profile);
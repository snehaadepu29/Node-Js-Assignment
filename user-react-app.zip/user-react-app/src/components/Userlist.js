import React, {Fragment, Component } from "react";
import axios from "axios";
import { withRouter } from "react-router-dom";
import { Table } from 'react-bootstrap';
import { getUser, removeUserSession } from './Common';

class Userlist extends Component {
  state = {
    usrdata: [], // empty array
  };



handleLogout = () => {
      removeUserSession();
      this.props.history.push('/');
    } 

  componentDidMount() {
    const user = getUser();
    if(user){
    const url = "http://localhost:3000/api/users";

    axios.get(`${url}`).then((res) => this.setState({ usrdata: res.data }));
  }
  }
  fun = () => {};

  render() {
    return (
<Fragment>
        {this.state.usrdata ? (
          <div className="heading1">
            <h3>User List </h3>
            
            
            <Table striped bordered hover>
            <thead>
            <tr>
              <td>Name</td>
              <td>Email</td>
              <td>Role</td>
            </tr>
             </thead>
  <tbody>
              {this.state.usrdata.map((res) => {
                return (
                  <tr> 
                    <td>{res.name}</td>
                    <td>{res.email}</td>
                    <td>{res.role}</td>
                  </tr>  
                );
              })}
              </tbody>
              </Table>
            <input type="button" onClick={this.handleLogout} value="Logout" />
          </div>
) : null}
        
      </Fragment>
    );
  }
}

export default withRouter(Userlist);

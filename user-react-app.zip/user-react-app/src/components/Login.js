import React, { Component } from 'react';
import axios from "axios";
import { getUser, setUserSession,removeUserSession } from './Common';
import { withRouter } from 'react-router-dom';

class Login extends Component {
  constructor(props) {
    super(props);

    this.state = {
      email: '',
      password: ''
    };

    this.update = this.update.bind(this);

    this.displayLogin = this.displayLogin.bind(this);
    
  }

  update(e) {
    let name = e.target.name;
    let value = e.target.value;
    this.setState({
      [name]: value
    });
  }

  displayLogin = (e) => {
    e.preventDefault();
    console.log('You are logged in');
    console.log(this.state);
    this.setState({
      email: '',
      password: ''
    });

     axios.post('http://localhost:3000/api/signin', { email: this.state.email, password: this.state.password }).then(response => {
     
      setUserSession(response.data.user);
      const user = response.data.user; //getUser();
    if(user) {
      const usrrole = user[0].role;
      if (usrrole === "EMPLOYEE") {
        this.props.history.push('/Profile');
      } else if (usrrole === "ADMIN") {
        this.props.history.push('/Userlist');
      } else {
        this.props.history.push('/');
      }
    }

    }).catch(error => {
      removeUserSession();
    });
   

  }

  render() {
    return (
      <div className="login">
        <form onSubmit={this.displayLogin}>
          <h2>Login</h2>
          <div className="username">
            <input
              type="email"
              placeholder="Email"
              value={this.state.email}
              onChange={this.update}
              name="email"
            />
          </div>

          <div className="password">
            <input
              type="password"
              placeholder="Password"
              value={this.state.password}
              onChange={this.update}
              name="password"
            />
          </div>

          <input type="submit" value="Submit" />
        </form>
      </div>
    );
  }
}

export default withRouter(Login);
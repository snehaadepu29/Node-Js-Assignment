const express = require('express');
const mariadb = require('mariadb');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const pool = mariadb.createPool({ host: 'localhost', user: 'root', password: "mariadb", database: 'mtnjs', connectionLimit: 5 });
const app = express();
const swaggerUi = require('swagger-ui-express');
const swaggerDocument = require('./swagger.json');
const customCss = fs.readFileSync((process.cwd()+"/swagger.css"), 'utf8');

app.use(cors());
app.use(express.json());
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument, {customCss}));
app.listen(3000, () => {
  console.log('App listening on port 3000!')
});



//Check database connection
pool.getConnection()
    .then(conn => {
      console.log("connected ! connection id is " + conn.threadId);
    })
    .catch(err => {
      console.log("not connected due to error: " + err);
});

//show all user list
app.get('/api/users',(req, res) => {
  let sql = "SELECT id,name,email,role from user";
  pool.query(sql)
	   .then(rows => {
	    res.json(rows.sort( sortbyname ));
	   })
	   .catch(err => {
	    console.log(err);
	});
});

//show all user list sorted by username
app.get('/api/userslist',(req, res) => {
  let sql = "SELECT id,name,email,role from user";
  pool.query(sql)
	   .then(rows => {
	    res.send(rows.sort( sortbyname ));
	   
	   })
	   .catch(err => {
	    console.log(err);
	});


});


//Filter by user name
function sortbyname(x, y) {
    let a = x.name.toUpperCase(),
        b = y.name.toUpperCase();
    return a == b ? 0 : a > b ? 1 : -1;
}

//show user details
app.get('/api/user/:userId',(req, res) => {
  let sql = "SELECT id,name,email,role FROM user WHERE id="+req.params.userId;
  pool.query(sql)
	   .then(row => {
	    res.send(row);
	   })
	   .catch(err => {
	    console.log(err);
	});
});


//show user details
app.post('/api/userdetails',(req, res) => {
	console.log(req.body.id);
  let sql = "SELECT id,name,email,role FROM user WHERE id="+req.body.id;
  pool.query(sql)
	   .then(row => {
	   	//console.log(row);
	    res.json(row);
	   })
	   .catch(err => {
	    console.log(err);
	});
});

//Check Valid Login user details 
app.post('/api/login',(req, res) => {
  let email = req.body.email;
  let pwd = req.body.password;
  let sql = "SELECT id,name,email,role FROM user WHERE email='"+email+"' and password='"+pwd+"'" ;
  pool.query(sql)
	   .then(row => {
	    if (row.length > 0) {
            res.send(row)
          } else {
            let msg = { "msg": 'Entered wrong credentials. Please try again with valid credentials.' }
            res.send(msg)
          }
	   })
	   .catch(err => {
	    console.log(err);
	});
});

//Check Valid Signin user details 
app.post('/api/signin',(req, res) => {
  let email = req.body.email;
  let pwd = req.body.password;
  let sql = "SELECT id,name,email,role FROM user WHERE email='"+email+"' and password='"+pwd+"'" ;
  pool.query(sql)
	   .then(row => {
	    if (row.length > 0) {
            res.json({user: row})
          } else {
            let msg = { "msg": 'Entered wrong credentials. Please try again with valid credentials.' }
            res.json(msg)
          }
	   })
	   .catch(err => {
	    console.log(err);
	});
});
